import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Suggestion } from './suggestion';

@NgModule({
  declarations: [
    Suggestion,
  ],
  imports: [
    IonicPageModule.forChild(Suggestion),
  ],
})
export class SuggestionModule {}
